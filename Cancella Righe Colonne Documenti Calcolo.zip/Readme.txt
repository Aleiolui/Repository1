L'utente desidera fornire al programma un documento 
di calcolo, insieme a un elenco di righe e colonne 
che vorrebbe venissero rimosse. Vorrebbe, infine, 
che il documento venisse esportato in formato CSV. 

Per evitare la necessità di inserire le istruzioni 
manualmente, ad ogni apertura del programma, l'utente 
vorrebbe che le stesse venissero precaricate all'avvio. 

Il programma riceve le istruzioni prelevandole da un file 
di testo esterno chiamato "Regole", presenta e chiede all'
utente di selezionare le istruzioni desiderate, gli permette
eventualmente di apportare delle modifiche alle istruzioni e 
infine utilizza queste istruzioni per modificare il documento, 
che viene esportato con il nome di "Output" in formato CSV. 

Le istruzioni di rimozione delle righe e colonne sono 
raggruppate in blocchi all'interno di un file di testo esterno 
chiamato "Regole", presente all'interno della cartella del 
programma. 

Se l'utente desidera aggiungere nuovi raggruppamenti all'elenco
deve rispettare l'ordine seguente: le istruzioni vanno scritte 
tutte sulla stessa linea di testo; le righe espresse in cifre; 
le colonne espresse in lettere; righe e colonne devono essere 
separate da un trattino. Un singolo raggruppamento di istruzioni
si compone di due linee di testo, di cui l'ultima è quella relativa 
alle istruzioni. La linea di testo che precede le istruzioni, ovvero
la prima, deve contenere un titolo, a piacere, che identifichi il 
raggruppamento. In ultimo, se l'utente aggiunge il carattere "due punti"
seguito da una cifra (n) alla fine della linea delle istruzioni, si 
chiederà al programma di non includere, nel documento finale, le 
ultime (n) righe. 

ESEMPIO:

Emporio del Risparmio
1-2-3-4-5-6-D-G-F-I-J-K-L-M-N-O-R-427-428-429:4
Negozio di Bruno
1-2-3-4-5-6-7-8-9-10-11-12-13-14-15-16-17-18-19-20-21-22-23-24-25-26-27-J-K-L-M-N